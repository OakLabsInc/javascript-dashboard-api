# dashboard.JwtVerifyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **String** |  | 
**email** | **String** |  | 
**displayName** | **String** |  | 
**customClaims** | [**CustomClaims**](CustomClaims.md) |  | 
**iat** | **Number** |  | 
**exp** | **Number** |  | 
**aud** | **String** |  | 
**iss** | **String** |  | 
**metadata** | **Object** |  | 


