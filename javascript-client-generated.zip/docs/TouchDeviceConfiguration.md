# dashboard.TouchDeviceConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calibration** | **String** |  | 
**orientation** | **String** |  | 


