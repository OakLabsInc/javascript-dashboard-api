# dashboard.DisplayConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  | [default to true]
**mode** | **String** |  | 
**reflect** | **String** |  | [default to &#39;NO_REFLECT&#39;]
**rotate** | **String** |  | [default to &#39;NO_ROTATE&#39;]
**transform** | **String** |  | 


