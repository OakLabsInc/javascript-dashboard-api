# dashboard.AutomaticStoreRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audio** | [**[AudioRequest]**](AudioRequest.md) |  | 
**display** | [**[DisplayRequest]**](DisplayRequest.md) |  | 
**touch** | [**[TouchRequest]**](TouchRequest.md) |  | 
**displayGlobal** | [**DisplayGlobalConfiguration**](DisplayGlobalConfiguration.md) |  | 


