# dashboard.AudioRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mixerId** | **String** |  | 
**configuration** | [**AudioConfiguration**](AudioConfiguration.md) |  | 


