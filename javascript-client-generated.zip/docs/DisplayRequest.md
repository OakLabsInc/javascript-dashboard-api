# dashboard.DisplayRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**displayId** | **String** |  | 
**configuration** | [**{String: DisplayConfiguration}**](DisplayConfiguration.md) |  | 


