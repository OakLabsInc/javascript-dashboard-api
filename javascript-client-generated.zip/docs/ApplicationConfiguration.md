# dashboard.ApplicationConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**username** | **String** |  | 
**password** | **String** |  | 
**environment** | [**ApplicationEnvironmentConfiguration**](ApplicationEnvironmentConfiguration.md) |  | 


