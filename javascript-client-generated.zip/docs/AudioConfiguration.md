# dashboard.AudioConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mute** | **Boolean** |  | 
**volume** | **Number** |  | 


