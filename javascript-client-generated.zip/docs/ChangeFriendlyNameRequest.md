# dashboard.ChangeFriendlyNameRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | friendly name, no special characters | 


