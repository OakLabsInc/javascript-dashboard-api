# dashboard.InstallRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**services** | [**[ApplicationConfiguration]**](ApplicationConfiguration.md) |  | 


