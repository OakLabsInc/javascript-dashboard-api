# dashboard.WifiConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ssid** | **String** |  | 
**passphrase** | **String** |  | 


