# dashboard.ForgetWifiRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ssid** | **String** |  | 


