# dashboard.DisplayGlobalConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dpi** | **Number** |  | 


