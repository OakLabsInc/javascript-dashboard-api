# dashboard.GenericReponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Error code of the call | [optional] [default to &#39;&quot;&quot;&#39;]
**details** | **String** | Error message | [optional] [default to &#39;&quot;&quot;&#39;]
**body** | **Object** |  | [optional] 


