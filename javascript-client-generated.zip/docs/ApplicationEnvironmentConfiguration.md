# dashboard.ApplicationEnvironmentConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NODE_ENV** | **String** |  | 


