# dashboard.CustomClaims

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | **String** |  | 
**domainUser** | **String** |  | 
**role** | **String** |  | 


