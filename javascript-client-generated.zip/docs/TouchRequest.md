# dashboard.TouchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**touchDeviceId** | **String** |  | 
**configuration** | [**TouchDeviceConfiguration**](TouchDeviceConfiguration.md) |  | 


